export type ColorVariant =
  | "primary"
  | "info"
  | "warning"
  | "error"
  | "secondary"
  | "success";
